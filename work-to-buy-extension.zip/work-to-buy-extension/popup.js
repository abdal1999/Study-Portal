document.getElementById("save").onclick = () => {
  const income = parseFloat(document.getElementById("income").value);
  const type = document.getElementById("type").value;

  let hourlyWage;

  if (type === "hourly") {
    hourlyWage = income;
  } else if (type === "daily") {
    hourlyWage = income / 8; // 8-hour workday
  } else if (type === "monthly") {
    hourlyWage = income / 160; // approx. 20 days x 8 hours
  }

  chrome.storage.local.set({ hourlyWage }, () => {
    document.getElementById("result").textContent = `Saved your income as ₹${hourlyWage.toFixed(2)} per hour`;
  });
};
