const seenPrices = new Set();

function isVisible(el) {
  const style = window.getComputedStyle(el);
  return style.display !== "none" && style.visibility !== "hidden" && el.offsetHeight > 0;
}

function isActualPrice(text) {
  return /^₹\s?\d{2,7}(\.\d{1,2})?$/.test(text.trim());
}

function processPrices(hourlyWage = 100) {
  const elements = document.querySelectorAll("span, div, p, strong, b");

  elements.forEach((el) => {
    if (!isVisible(el)) return;

    const rawText = el.textContent.replace(/,/g, '').trim();
    if (!isActualPrice(rawText)) return;

    const match = rawText.match(/₹\s?(\d+(\.\d+)?)/);
    if (!match) return;

    const priceText = match[0]; // like ₹1799
    const price = parseFloat(match[1]);

    // Skip if already tagged by price text at this location
    const key = priceText + "::" + el.innerText;
    if (seenPrices.has(key)) return;
    seenPrices.add(key);

    const hours = (price / hourlyWage).toFixed(1);
    let message = `₹ ~${hours} hrs of your work`;

    if (hours > 12) message += " – Big spend! 🧠";
    else if (hours > 6) message += " – Worth a pause 🤔";
    else message += " – Feels fair 🎯";

    const tag = document.createElement("span");
    tag.className = "work-hours-tag";
    tag.textContent = " " + message;
    tag.style.background = "#e6f2ff";
    tag.style.color = "#004085";
    tag.style.marginLeft = "6px";
    tag.style.padding = "2px 6px";
    tag.style.borderRadius = "6px";
    tag.style.fontSize = "12px";
    tag.style.fontWeight = "bold";
    tag.style.border = "1px solid #b8daff";

    el.appendChild(tag);
  });
}

function startObserver(hourlyWage) {
  let timeoutId = null;

  const observer = new MutationObserver(() => {
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = setTimeout(() => processPrices(hourlyWage), 200);
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

chrome.storage.local.get("hourlyWage", (result) => {
  const wage = result.hourlyWage || 100;
  processPrices(wage);
  startObserver(wage);
});
